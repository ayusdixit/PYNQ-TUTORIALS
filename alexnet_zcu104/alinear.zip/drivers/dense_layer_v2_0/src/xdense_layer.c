// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xdense_layer.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDense_layer_CfgInitialize(XDense_layer *InstancePtr, XDense_layer_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDense_layer_Start(XDense_layer *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDense_layer_IsDone(XDense_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDense_layer_IsIdle(XDense_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDense_layer_IsReady(XDense_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDense_layer_EnableAutoRestart(XDense_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XDense_layer_DisableAutoRestart(XDense_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_AP_CTRL, 0);
}

void XDense_layer_Set_inputs(XDense_layer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_INPUTS_DATA, (u32)(Data));
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_INPUTS_DATA + 4, (u32)(Data >> 32));
}

u64 XDense_layer_Get_inputs(XDense_layer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_INPUTS_DATA);
    Data += (u64)XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_INPUTS_DATA + 4) << 32;
    return Data;
}

void XDense_layer_Set_weights(XDense_layer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_WEIGHTS_DATA, (u32)(Data));
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_WEIGHTS_DATA + 4, (u32)(Data >> 32));
}

u64 XDense_layer_Get_weights(XDense_layer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_WEIGHTS_DATA);
    Data += (u64)XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_WEIGHTS_DATA + 4) << 32;
    return Data;
}

void XDense_layer_Set_bias(XDense_layer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XDense_layer_Get_bias(XDense_layer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XDense_layer_Set_final(XDense_layer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_FINAL_DATA, (u32)(Data));
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_FINAL_DATA + 4, (u32)(Data >> 32));
}

u64 XDense_layer_Get_final(XDense_layer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_FINAL_DATA);
    Data += (u64)XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_FINAL_DATA + 4) << 32;
    return Data;
}

void XDense_layer_InterruptGlobalEnable(XDense_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_GIE, 1);
}

void XDense_layer_InterruptGlobalDisable(XDense_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_GIE, 0);
}

void XDense_layer_InterruptEnable(XDense_layer *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_IER);
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_IER, Register | Mask);
}

void XDense_layer_InterruptDisable(XDense_layer *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_IER);
    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XDense_layer_InterruptClear(XDense_layer *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDense_layer_WriteReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_ISR, Mask);
}

u32 XDense_layer_InterruptGetEnabled(XDense_layer *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_IER);
}

u32 XDense_layer_InterruptGetStatus(XDense_layer *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDense_layer_ReadReg(InstancePtr->Control_BaseAddress, XDENSE_LAYER_CONTROL_ADDR_ISR);
}

