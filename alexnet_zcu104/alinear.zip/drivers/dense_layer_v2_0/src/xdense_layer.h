// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XDENSE_LAYER_H
#define XDENSE_LAYER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdense_layer_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XDense_layer_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XDense_layer;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDense_layer_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDense_layer_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDense_layer_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDense_layer_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XDense_layer_Initialize(XDense_layer *InstancePtr, u16 DeviceId);
XDense_layer_Config* XDense_layer_LookupConfig(u16 DeviceId);
int XDense_layer_CfgInitialize(XDense_layer *InstancePtr, XDense_layer_Config *ConfigPtr);
#else
int XDense_layer_Initialize(XDense_layer *InstancePtr, const char* InstanceName);
int XDense_layer_Release(XDense_layer *InstancePtr);
#endif

void XDense_layer_Start(XDense_layer *InstancePtr);
u32 XDense_layer_IsDone(XDense_layer *InstancePtr);
u32 XDense_layer_IsIdle(XDense_layer *InstancePtr);
u32 XDense_layer_IsReady(XDense_layer *InstancePtr);
void XDense_layer_EnableAutoRestart(XDense_layer *InstancePtr);
void XDense_layer_DisableAutoRestart(XDense_layer *InstancePtr);

void XDense_layer_Set_inputs(XDense_layer *InstancePtr, u64 Data);
u64 XDense_layer_Get_inputs(XDense_layer *InstancePtr);
void XDense_layer_Set_weights(XDense_layer *InstancePtr, u64 Data);
u64 XDense_layer_Get_weights(XDense_layer *InstancePtr);
void XDense_layer_Set_bias(XDense_layer *InstancePtr, u64 Data);
u64 XDense_layer_Get_bias(XDense_layer *InstancePtr);
void XDense_layer_Set_final(XDense_layer *InstancePtr, u64 Data);
u64 XDense_layer_Get_final(XDense_layer *InstancePtr);

void XDense_layer_InterruptGlobalEnable(XDense_layer *InstancePtr);
void XDense_layer_InterruptGlobalDisable(XDense_layer *InstancePtr);
void XDense_layer_InterruptEnable(XDense_layer *InstancePtr, u32 Mask);
void XDense_layer_InterruptDisable(XDense_layer *InstancePtr, u32 Mask);
void XDense_layer_InterruptClear(XDense_layer *InstancePtr, u32 Mask);
u32 XDense_layer_InterruptGetEnabled(XDense_layer *InstancePtr);
u32 XDense_layer_InterruptGetStatus(XDense_layer *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
